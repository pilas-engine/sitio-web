document.addEventListener("DOMContentLoaded", function() {
  var opciones = {
    maximizar: true,
    pixelart: false,
  }

  var recursos = {
    sonidos: [],
    huesos: []
  }

  var animaciones: [
      {
        "nombre": "parado",
        "cuadros": [{ "nombre": "mario"} ],
        "velocidad": 10
      },

      {
        "nombre": "salta",
        "cuadros": [{ "nombre": "mario6"} ],
        "velocidad": 10
      },

      {
        "nombre": "camina",
        "cuadros": [
          {"nombre": "mario_4"},
          {"nombre": "mario_2"},
          {"nombre": "mario_4"},
          {"nombre": "mario_3"},
        ],
        "velocidad": 10
      },

    ],
  }

  var imagenes = [
    {
      nombre: "fondo",
      ruta: "imagenes/fondo.png",
    },
    {
      nombre: "mario",
      ruta: "imagenes/mario-parado.png",
    },
    {
      nombre: "mario6",
      ruta: "imagenes/mario_6.png",
    },
    {
      nombre: "mario_4",
      ruta: "imagenes/mario_4.png",
    },
    {
      nombre: "mario_2",
      ruta: "imagenes/mario_2.png",
    },
    {
      nombre: "mario_3",
      ruta: "imagenes/mario_3.png",
    },
    {
      nombre: "plataforma",
      ruta: "imagenes/plataforma.png"
    },
  ];

  var pilas = pilasengine.iniciar(500, 500, recursos, opciones, imagenes, true);

  class Mario extends Actor {
    propiedades = {
      figura: "rectangulo",
      imagen: "mario",
      etiqueta: "mario",
      escala_x: 2,
      escala_y: 2,
      y: 100,
      figura_ancho: 20,
      figura_alto: 61,
      figura_dinamica: true,
      figura_rebote: 0,
      figura_sin_rotacion: true,
      z: -2,
    };

    iniciar() {
      // los sensores se tienen que crear manualmente
      // en el modo biblioteca:
      //                  (ancho, alto, x, y, nombre)
      this.agregar_sensor(30, 13, 0, -28, "pies");

      let pies = this.obtener_sensor("pies");
      this.estado = "parado";
    }

    toca_el_suelo() {
      var pies = this.obtener_sensor("pies");
      if (this.velocidad_y <= 0.1) {
        return pies.colisiona_con_etiqueta("plataforma");
      }
    }

    actualizar() {
    }

    parado_iniciar() {
      this.animacion = "parado";
    }

    parado_actualizar() {
        if (this.control.izquierda || this.control.derecha) {
            this.estado = "camina";
        }

        if (this.control.arriba) {
            if (this.toca_el_suelo()) {
                this.impulsar(0, 10);
                this.estado = "salta";
            }
        }
    }

    camina_iniciar() {
      this.animacion = "camina";
    }

    camina_actualizar() {

        var control = this.control;
        if (this.control.arriba) {
            if (this.toca_el_suelo()) {
                this.impulsar(0, 10);
                this.estado = "salta";
                return;
            }
        }

        if (control.izquierda) {
            this.x -= 3;
            this.espejado = true;
            return;
        }

        if (control.derecha) {
            this.x += 3;
            this.espejado = false;
            return;
        }

        if (!control.izquierda && !control.derecha) {
            this.estado = "parado";
            return;
        }
    }

    salta_iniciar() {
      this.animacion = "salta";
    }

    salta_actualizar() {
        if (this.toca_el_suelo()) {
            this.estado = "parado";
        }

        if (this.control.izquierda) {
            this.x -= 3;
            this.espejado = true;
        }

        if (this.control.derecha) {
            this.x += 3;
            this.espejado = false;
        }
    }

  }

  class Plataforma extends Actor {
    propiedades = {
      figura: "rectangulo",
      imagen: "plataforma",
      etiqueta: "plataforma",
      y: 0,
      escala_x: 1,
      escala_y: 1,
      centro_x: 0.5,
      centro_y: 0.5,
      figura_ancho: 250,
      figura_alto: 40,
      figura_dinamica: false,
      figura_rebote: 0

    };

    iniciar() {
    }

    actualizar() {
    }

    cuando_hace_click() {
    }
  }

  pilas.onready = function() {
    pilas.modo.crear_fondo("fondo", 0, 0)
    pilas.animaciones.reemplazar_todas_las_animaciones(recursos.animaciones);

    let mario = pilas.actores.crear_actor("nombre", Mario)
    let suelo = pilas.actores.crear_actor("suelo", Plataforma)

  }
});
